
#include <assert.h>
#include <ctype.h>
#include <errno.h>
#include <float.h>
#include <limits.h>
#include <locale.h>
#include <math.h>
#include <setjmp.h>
#include <signal.h>
#include <stdarg.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <conio.h>
#include <dos.h>
#include <fcntl.h>
#include <io.h>
#include <process.h>
#include <share.h>
#include <malloc.h>

int main(int argc, char *argv[])
{
	FILE *file;
	char *p;
	int i;	

	// assert.h
	assert(0 == 0);

	// ctype.h
	isalnum( 65 );

	// float.h
	_fpreset();

	// locale.h
	localeconv();

	// math.h
	abs(-1);

	// setjmp.h
	// ...

	// process.h
	i = execl("C:\1.exe", "1.exe");
	perror("error");

	// malloc.h
	p = (char *)malloc(10);

	// stdlib.h
	system("Echo test stdlib.h");

	// string.h
	sprintf(p, "%s", "Hi this is a test!");

	printf("%s%s", "Hello, world\n", p);

	return 0;
}
